document.addEventListener("DOMContentLoaded", function () {
    const weatherData = window.weatherData;
    const cities = window.cities;

    cities.forEach(city => {
        const dataList = weatherData[city];
        if (dataList && dataList.length > 0) {
            let labels = dataList.map(d => {
                let date = new Date(d.date);
                return `${date.getDate()}/${date.getMonth() + 1}`;
            });

            let temps = dataList.map(d => d.temperature);

            const ctx = document.getElementById("chart-" + city).getContext('2d');
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Temperatura Media (°C)',
                        data: temps,
                        fill: false,
                        borderColor: 'rgba(255, 99, 132, 1)',
                        tension: 0.2
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: false,
                            title: {
                                display: true,
                                text: 'Temperatura (°C)'
                            }
                        },
                        x: {
                            title: {
                                display: true,
                                text: 'Data'
                            }
                        }
                    }
                }
            });
        }
    });
});
