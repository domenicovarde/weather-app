package com.example.weatherapp.controller;

import com.example.weatherapp.model.WeatherData;
import com.example.weatherapp.service.WeatherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
public class WeatherController {
    
    @Autowired
    private WeatherService weatherService;
    
    @GetMapping("/")
    public String index(Model model) {
        List<WeatherData> weatherData = weatherService.getWeatherDataLast14Days();
        
        // Raggruppa i dati per città
        Map<String, List<WeatherData>> groupedData = weatherData.stream()
            .collect(Collectors.groupingBy(WeatherData::getCity));
        
        model.addAttribute("weatherData", groupedData);
        model.addAttribute("cities", weatherService.getCities());
        
        return "index";
    }
    
    @PostMapping("/refresh")
    public String refreshData() {
        weatherService.fetchAndStoreWeatherData();
        return "redirect:/";
    }
}