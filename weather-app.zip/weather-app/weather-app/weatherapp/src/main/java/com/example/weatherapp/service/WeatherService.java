package com.example.weatherapp.service;

import com.example.weatherapp.model.WeatherData;
import com.example.weatherapp.repository.WeatherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
public class WeatherService {
    
    @Autowired
    private WeatherRepository weatherRepository;
    
    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();
    
    // Coordinate delle città italiane
    private final Map<String, double[]> cityCoordinates = Map.of(
        "Roma", new double[]{41.9028, 12.4964},
        "Milano", new double[]{45.4642, 9.1900},
        "Napoli", new double[]{40.8518, 14.2681},
        "Torino", new double[]{45.0703, 7.6869},
        "Firenze", new double[]{43.7696, 11.2558},
        "Bologna", new double[]{44.4949, 11.3426},
        "Venezia", new double[]{45.4408, 12.3155},
        "Bari", new double[]{41.1171, 16.8719}
    );
    
    public void fetchAndStoreWeatherData() {
        LocalDate endDate = LocalDate.now();
        LocalDate startDate = endDate.minusDays(14);
        
        for (Map.Entry<String, double[]> entry : cityCoordinates.entrySet()) {
            String city = entry.getKey();
            double[] coords = entry.getValue();
            
            try {
                String url = String.format(
                    "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f&daily=temperature_2m_mean&start_date=%s&end_date=%s",
                    coords[0], coords[1], startDate.toString(), endDate.toString()
                );
                
                String response = restTemplate.getForObject(url, String.class);
                JsonNode jsonNode = objectMapper.readTree(response);
                
                JsonNode daily = jsonNode.get("daily");
                JsonNode dates = daily.get("time");
                JsonNode temperatures = daily.get("temperature_2m_mean");
                
                // Pulisci i dati esistenti per questa città
                weatherRepository.deleteAll(weatherRepository.findByCityAndDateBetween(city, startDate, endDate));
                
                for (int i = 0; i < dates.size(); i++) {
                    LocalDate date = LocalDate.parse(dates.get(i).asText());
                    Double temperature = temperatures.get(i).asDouble();
                    
                    WeatherData weatherData = new WeatherData(city, date, temperature, coords[0], coords[1]);
                    weatherRepository.save(weatherData);
                }
                
            } catch (Exception e) {
                System.err.println("Errore nel recupero dati per " + city + ": " + e.getMessage());
            }
        }
    }
    
    public List<WeatherData> getWeatherDataLast14Days() {
        LocalDate startDate = LocalDate.now().minusDays(14);
        return weatherRepository.findWeatherDataFromDate(startDate);
    }
    
    public List<String> getCities() {
        return new ArrayList<>(cityCoordinates.keySet());
    }
}