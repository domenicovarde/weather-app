package com.example.weatherapp.repository;

import com.example.weatherapp.model.WeatherData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface WeatherRepository extends JpaRepository<WeatherData, Long> {
    
    @Query("SELECT w FROM WeatherData w WHERE w.date >= :startDate ORDER BY w.city, w.date")
    List<WeatherData> findWeatherDataFromDate(LocalDate startDate);
    
    @Query("SELECT DISTINCT w.city FROM WeatherData w ORDER BY w.city")
    List<String> findDistinctCities();
    
    List<WeatherData> findByCityAndDateBetween(String city, LocalDate startDate, LocalDate endDate);
}